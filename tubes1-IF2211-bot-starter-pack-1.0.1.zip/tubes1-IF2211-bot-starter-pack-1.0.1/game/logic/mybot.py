from game.logic.base import BaseLogic
from game.models import Board, GameObject

class Mybot(BaseLogic):
    def _init_(self):
        super()._init_()
        self.my_attribute = 0

    def next_move(self, board_bot: GameObject, board: Board):
        delta_x = 1
        delta_y = 0
        return delta_x, delta_y