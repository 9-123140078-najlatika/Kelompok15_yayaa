#Najlatika_123140078
#Hanifah Hasanah_123140082
#Kelompok 15 ( yayaa )

from game.logic.base import BaseLogic
from game.models import GameObject, Board, Position
from game.util import get_direction

class GreedyBot(BaseLogic):
    def init(self):
        super().init()

    def next_move(self, board_bot: GameObject, board: Board):
        props = board_bot.properties
        current_pos = board_bot.position

        def find_valid_direction_to(goal_pos):
            dx, dy = get_direction(current_pos.x, current_pos.y, goal_pos.x, goal_pos.y)
            if dx == dy or (dx == 0 and dy == 0):
                alt_moves = []
                if dx != 0:
                    alt_moves.append((dx, 0))
                if dy != 0:
                    alt_moves.append((0, dy))

                for move in alt_moves:
                    if board.is_valid_move(current_pos, move[0], move[1]):
                        return move
                if board.is_valid_move(current_pos, 1, 0):
                    return 1, 0
                if board.is_valid_move(current_pos, 0, 1):
                    return 0, 1
                if board.is_valid_move(current_pos, -1, 0):
                    return -1, 0
                if board.is_valid_move(current_pos, 0, -1):
                    return 0, -1
                return 1, 0
            else:
                if board.is_valid_move(current_pos, dx, dy):
                    return dx, dy
                alt_moves = []
                if dx != 0:
                    alt_moves.append((dx, 0))
                if dy != 0:
                    alt_moves.append((0, dy))
                for move in alt_moves:
                    if board.is_valid_move(current_pos, move[0], move[1]):
                        return move
                if board.is_valid_move(current_pos, 1, 0):
                    return 1, 0
                if board.is_valid_move(current_pos, 0, 1):
                    return 0, 1
                if board.is_valid_move(current_pos, -1, 0):
                    return -1, 0
                if board.is_valid_move(current_pos, 0, -1):
                    return 0, -1
                return 1, 0

        if props.diamonds >= 5:
            goal = props.base
            return find_valid_direction_to(goal)

        diamond_positions = [obj.position for obj in board.game_objects if obj.type == "diamond"]
        if diamond_positions:
            diamond_positions.sort(key=lambda p: abs(p.x - current_pos.x) + abs(p.y - current_pos.y))
            for diamond_pos in diamond_positions:
                dx, dy = get_direction(current_pos.x, current_pos.y, diamond_pos.x, diamond_pos.y)
                move = find_valid_direction_to(diamond_pos)
                if move != (1, 0) or board.is_valid_move(current_pos, 1, 0):
                    return move

            if board.is_valid_move(current_pos, 1, 0):
                return 1, 0
            if board.is_valid_move(current_pos, 0, 1):
                return 0, 1
            if board.is_valid_move(current_pos, -1, 0):
                return -1, 0
            if board.is_valid_move(current_pos, 0, -1):
                return 0, -1

            return 1, 0 

        if board.is_valid_move(current_pos, 1, 0):
            return 1, 0
        if board.is_valid_move(current_pos, 0, 1):
            return 0, 1
        if board.is_valid_move(current_pos, -1, 0):
            return -1, 0
        if board.is_valid_move(current_pos, 0, -1):
            return 0, -1
        return 1, 0